/*====================
   Auth tab
=======================*/
function loginClick() {
    var loginTab = document.getElementById('login-tab');
    loginTab.click();
}
function signupClick() {
    var signupTab = document.getElementById('signup-tab');
    signupTab.click();
}